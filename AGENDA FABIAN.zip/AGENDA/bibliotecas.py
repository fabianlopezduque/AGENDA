cuentas = {}
contacto = {}
num_cuenta = 1