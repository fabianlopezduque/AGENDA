from bibliotecas import *

def login():
    nombre = input("Ingrese el nombre del usuario: ").capitalize()
    clave = input("Ingrese la clave del usuario: ")
    usuarioEncontrado = False
    #recorrido en el diccionario cuentas verificando los valores
    for i in cuentas.values():
        if i['nombre'] == nombre and i['clave'] == clave:
            usuarioEncontrado = True
            print("Usuario existente")
            #Con este return si se llega a encontrar podremos hacer la validacion en otra funcion con un if login or un else , y se almacena el numero de cuenta principal
            return i["num_cuenta"]
        #El if not sirve para verificar que el usuarioEncontrado sigue siendo falso , osea que sigue siendo True que es aun falso 
    if not usuarioEncontrado:
        print("Datos incorrectos")
        #El return false se aplica para que en las otras funciones se use este return y ver si se cumple o no con un condicional
        return False
    