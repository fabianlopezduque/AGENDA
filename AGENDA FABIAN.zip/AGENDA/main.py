from DirectorioFABIAN import *

#para que funcione un while siempre debe ser verdadero(while true)
def menu():
    while True:
        print("==Menu directorio==")
        print("")
        print("1.Registro")
        print("2.Agregar contactos")
        print("3.Contactos")
        print("0.Salir")
        opc = int(input("Ingrese la opcion que desee: "))
        if opc == 1:
            registrar()
        elif opc == 2:
            contactos()
        elif opc == 3:
            listar()
        elif opc == 0:
            break
        else:
            print("Dato incorrecto , ingrese otro")

menu()
