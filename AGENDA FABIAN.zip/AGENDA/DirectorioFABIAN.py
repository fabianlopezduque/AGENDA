from bibliotecas import *
from login import *

#funcion registrar
def registrar():
    global num_cuenta
    #capitalize escrie en mayuscula la primera letra
    nombre = input("Ingrese el nombre del usuario: ").capitalize()
    clave = input("Ingrese la clave del usuario: ")
    cuentas[num_cuenta] = {"num_cuenta": num_cuenta, "nombre": nombre, "clave": clave}
    #diccionario vacio, el cual guardara informacion de la cuanta
    contacto[num_cuenta] = {}
    print("")
    print("Usuario creado con exito!")
    print(cuentas)
    #contador para numeros de cuentas, para que vaya sumando de a uno.
    num_cuenta += 1


    
#funcion contacto
def contactos():
    #Con esto, almacenamos el return sea falso o el numero de cuenta , num cuenta actual almacena el numero de cuenta ,de el numero de en el login
    num_cuenta_actual = login()
    if num_cuenta_actual:
        print("Accediendo...")
        while True:
            print("Desea agregar algun contacto: S/N ")
            opc = input("Ingrese su eleccion: ").upper()
            if opc == "S":
                nombreContact = input("Ingrese el nombre del contacto: ").capitalize()
                numberContact = int(input("Ingrese el numero telefonico del contacto: "))
                direContact = input("Ingrese la direccion del contacto: ")
                emailContact = input("Ingrese el correo del contacto: ")
                # con este len , hacemos que cuente el indice y nos indique cuanto se tiene en el momento , 
                # y por cada contacto que se inserte se van a sumar 1 , para que el indice aumente y no se reemplacen los contactos 
                contacto[num_cuenta_actual][len(contacto[num_cuenta_actual])+1] = {
                    "Nombre": nombreContact,
                    "Telefono": numberContact,
                    "Direccion": direContact,
                    "Correo": emailContact
                }
                print("Contacto agregado con exito!")
                print(contacto)
            elif opc == "N":
                print("Gracias por su tiempo...")
                return
            else:
                print("Opcion no valida")
    else:
        print("Usuario no encontrado...")

#funcion listar
def listar():
    num_cuenta_actual = login()
    if num_cuenta_actual:
        print("Accediendo...")
        if contacto[num_cuenta_actual]:
            while True:
                print("Desea buscar un contacto por: ")
                print("1.Nombre")
                print("2.Telefono")
                print("3.Listar todos los contactos")
                opc = input("Ingrese su eleccion: ")

                if opc == "1":
                    nombre_buscar = input("Ingrese el nombre del contacto a buscar: ").capitalize()
                    encontrado = False
                    for num, dato in contacto[num_cuenta_actual].items():
                        if dato["Nombre"] == nombre_buscar:
                            print(f"Contacto encontrado: Nombre: {dato['Nombre']}, Numero: {dato['Telefono']}, Direccion: {dato['Direccion']}, Email: {dato['Correo']}")
                            encontrado = True
                    if not encontrado:
                        print(f"Contacto con el nombre {nombre_buscar} no fue encontrado.")

                elif opc == "2":
                    telefono_buscar = int(input("Ingrese el numero telefonico del contacto a buscar: "))
                    encontrado = False
                    for num, dato in contacto[num_cuenta_actual].items():
                        if dato["Telefono"] == telefono_buscar:
                            print(f"Contacto encontrado: Nombre: {dato['Nombre']}, Numero: {dato['Telefono']}, Direccion: {dato['Direccion']}, Email: {dato['Correo']}")
                            encontrado = True
                    if not encontrado:
                        print(f"Contacto con el numero {telefono_buscar} no fue encontrado.")
                  #Verifica si hay contactos con el numero de cuenta actual
                elif opc == "3":
                    for num, dato in contacto[num_cuenta_actual].items():
                        print(f"El contacto {num}: Nombre: {dato['Nombre']}, Numero: {dato['Telefono']}, Direccion: {dato['Direccion']}, Email: {dato['Correo']}")
                    break

                else:
                    print("Opcion no valida")
        else:
            print("No se encuentran contactos en este numero de cuenta")
    else:
        print("Usuario no encontrado...")

